$(function() {
    //onload / onclick
});

