const BeforeAfterActionFlags_None = 0;
const BeforeAfterActionFlags_Own = 1;
const BeforeAfterActionFlags_Global = 2;

const RegionType_None = 0;
const RegionType_VerticalSplit = 1;
const RegionType_HorizontalSplit = 2;
const RegionType_Quadrant = 3;
const RegionType_Grid = 4;
const RegionType_Custom = 5;