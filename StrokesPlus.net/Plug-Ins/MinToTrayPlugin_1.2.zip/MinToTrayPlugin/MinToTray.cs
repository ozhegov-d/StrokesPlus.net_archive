﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MinToTrayPlugin
{
    public static class MinToTray
    {
        static TrayForm frmTrayForm = null;
        static Dictionary<IntPtr, Win32.WINDOWINFO> m_wndTray;
        delegate void Emptydel();
        static object initLock = new object();

        static MinToTray()
        {

        }

        public static void StrokesPlusInitStaticPlugin(object engine)
        {
            lock (initLock)
            {
                if (m_wndTray == null) m_wndTray = new Dictionary<IntPtr, Win32.WINDOWINFO>();
                if (frmTrayForm == null)
                {
                    frmTrayForm = new TrayForm();
                    frmTrayForm.Show();
                }
            }
        }

        public static void SendToTray(IntPtr activeWnd)
        {
            StringBuilder title = new StringBuilder(256);
            Win32.WINDOWINFO info = new Win32.WINDOWINFO();
            Win32.GetWindowText(activeWnd, title, 256);
            Emptydel del = delegate ()
            {
                Win32.GetWindowInfo(activeWnd, ref info);
                if (m_wndTray.ContainsKey(activeWnd))
                    m_wndTray[activeWnd] = info;
                else
                {
                    m_wndTray.Add(activeWnd, info);
                    NotifyIcon tray = new NotifyIcon();
                    tray.Visible = true;
                    tray.Tag = activeWnd;
                    tray.Icon = GetWindowIcon(activeWnd);
                    tray.Text = title.Length >= 64 ? title.ToString().Substring(0, 60) + "..." : title.ToString();
                    tray.Click += new EventHandler(tray_Click);
                    TrayForm.TrayIcons.Add(tray);
                }
                Win32.ShowWindow(activeWnd, 0);//hide
            };
            frmTrayForm.Invoke(del);
        }

        public static void ShowAllTrayWindows()
        {
            while (TrayForm.TrayIcons.Count > 0)
            {
                NotifyIcon tray = TrayForm.TrayIcons[0];
                tray_Click(tray, null);
            }
        }

        private static void tray_Click(object sender, EventArgs e)
        {
            NotifyIcon tray = sender as NotifyIcon;
            IntPtr hWnd = (IntPtr)tray.Tag;
            Win32.WINDOWINFO info;

            if (m_wndTray.ContainsKey(hWnd))
            {
                info = m_wndTray[hWnd];
                SetWindowFromInfo(hWnd, info);
                m_wndTray.Remove(hWnd);
            }
            else
            {
                Win32.ShowWindow(hWnd, 1);//show
            }
            Win32.SetForegroundWindow(hWnd);

            tray.Click -= new EventHandler(tray_Click);
            TrayForm.TrayIcons.Remove(tray);
            tray.Dispose();
        }

        static Icon GetWindowIcon(IntPtr hWnd)
        {
            IntPtr mainWindow = hWnd; 
            IntPtr hIcon = Win32.SendMessage(mainWindow, Win32.WM_GETICON, Win32.ICON_BIG, 0);
            if (hIcon == IntPtr.Zero)
            {
                string path = AppGroupOptions.GetPathFromHwnd(hWnd);
                if (path != string.Empty)
                {
                    try
                    {
                        return Icon.ExtractAssociatedIcon(path);
                    }
                    catch
                    {
                        hIcon = frmTrayForm.Icon.Handle;
                    }
                }
                else hIcon = frmTrayForm.Icon.Handle;
            }
            return Icon.FromHandle(hIcon);
        }

        private static void SetWindowFromInfo(IntPtr hwnd, Win32.WINDOWINFO info)
        {
            int x1 = info.rcWindow.left;
            int y1 = info.rcWindow.top;
            int x2 = info.rcWindow.right - x1;
            int y2 = info.rcWindow.bottom - y1;
            Win32.SetWindowPos(hwnd, Win32.HWND_NOTOPMOST, x1, y1, x2, y2, Win32.SWP_SHOWWINDOW);
        }
    }

    internal class AppGroupOptions
    {
        public static string GetPathFromHwnd(IntPtr hWnd)
        {
            if (hWnd == IntPtr.Zero) return string.Empty;
            int procId;
            Win32.GetWindowThreadProcessId(hWnd, out procId);

            // this method is much faster then the below one
            const int nChars = 1024;
            StringBuilder filenameBuffer = new StringBuilder(nChars);
            IntPtr hProcess = Win32.OpenProcess(1040, false, procId);
            Win32.GetModuleFileNameEx(hProcess, IntPtr.Zero, filenameBuffer, nChars);
            Win32.CloseHandle(hProcess);
            string fileName = filenameBuffer.ToString();

            // if file doesn't exist use previous and slower method
            if (!File.Exists(fileName))
            {
                Process foregroundProc = Process.GetProcessById(procId);
                filenameBuffer = new StringBuilder(500);
                try
                {
                    Win32.GetLongPathName(foregroundProc.MainModule.FileName, filenameBuffer, 500);
                }
                catch (Exception ex) //this exception might occure on 64bit windows because of MainModule!            
                {
                    fileName = string.Empty;
                }
                if (fileName != string.Empty)
                    fileName = filenameBuffer.ToString();

            }
            return fileName;

            // this check has to be commented because the BAT! email client has this attribute Zero, but mainModule is OK
            //if (foregroundProc.MainWindowHandle == IntPtr.Zero) return string.Empty;
        }
    }

    internal class Win32
    {
        [DllImport("user32.dll")]
        public static extern void SetWindowPos(IntPtr hWnd, int hwndInsertAfter, int X, int Y, int width, int height, uint flags);

        [DllImport("user32.dll")]
        public static extern IntPtr GetWindowText(IntPtr hWnd, StringBuilder text, int count);

        [DllImport("User32")]
        public static extern int ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        public static extern bool GetWindowInfo(IntPtr hwnd, ref WINDOWINFO pwi);

        [DllImport("user32.dll")]
        public static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);

        [DllImport("kernel32.dll")]
        public static extern int GetLongPathName(string path, StringBuilder longPath, int longPathLength);

        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);

        [DllImport("kernel32.dll")]
        public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("psapi.dll")]
        public static extern uint GetModuleFileNameEx(IntPtr hProcess, IntPtr hModule, [Out] StringBuilder lpBaseName, [In][MarshalAs(UnmanagedType.U4)] int nSize);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool CloseHandle(IntPtr hObject);

        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        public const int SWP_ASYNCWINDOWPOS = 0x4000;
        public const int SWP_DEFERERASE = 0x2000;
        public const int SWP_DRAWFRAME = 0x0020;
        public const int SWP_FRAMECHANGED = 0x0020;
        public const int SWP_HIDEWINDOW = 0x0080;
        public const int SWP_NOACTIVATE = 0x0010;
        public const int SWP_NOCOPYBITS = 0x0100;
        public const int SWP_NOMOVE = 0x0002;
        public const int SWP_NOOWNERZORDER = 0x0200;
        public const int SWP_NOREDRAW = 0x0008;
        public const int SWP_NOREPOSITION = 0x0200;
        public const int SWP_NOSENDCHANGING = 0x0400;
        public const int SWP_NOSIZE = 0x0001;
        public const int SWP_NOZORDER = 0x0004;
        public const int SWP_SHOWWINDOW = 0x0040;

        public const int WM_GETICON = 0x007F;
        public const int ICON_SMALL = 0;
        public const int ICON_BIG = 1;

        public const int HWND_TOP = 0;
        public const int HWND_BOTTOM = 1;
        public const int HWND_TOPMOST = -1;
        public const int HWND_NOTOPMOST = -2;

        [StructLayout(LayoutKind.Sequential)]
        internal struct WINDOWINFO
        {
            public UInt32 cbSize;
            public RECT rcWindow;
            public RECT rcClient;
            public UInt32 dwStyle;
            public UInt32 dwExStyle;
            public UInt32 dwWindowStatus;
            public UInt32 cxWindowBorders;
            public UInt32 cyWindowBorders;
            public UInt16 atomWindowType;
            public UInt16 wCreatorVersion;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct RECT
        {
            public Int32 left;
            public Int32 top;
            public Int32 right;
            public Int32 bottom;

            public RECT(Rectangle _rect)
            {
                left = _rect.Left;
                top = _rect.Top;
                right = _rect.Right;
                bottom = _rect.Bottom;
            }

            public RECT(RectangleF _rect)
            {
                left = (int)_rect.Left;
                top = (int)_rect.Top;
                right = (int)_rect.Right;
                bottom = (int)_rect.Bottom;
            }
        }
    }
}
