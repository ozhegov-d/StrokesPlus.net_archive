﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MinToTrayPlugin
{
    public partial class TrayForm : Form
    {
        static List<NotifyIcon> m_trayIcons;
        public static List<NotifyIcon> TrayIcons { get { return m_trayIcons; } set { m_trayIcons = value; } }

        public TrayForm()
        {
            InitializeComponent();
            m_trayIcons = new List<NotifyIcon>();
        }

        protected override void OnLoad(EventArgs e)
        {
            this.Visible = false;
            this.ShowInTaskbar = false;
            base.OnLoad(e);
        }

        protected override bool ShowWithoutActivation
        {
            get { return true; }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.Style |= unchecked((int)0x80000000);    // WS_POPUP
                cp.ExStyle |= (0x00000080                // WS_EX_TOOLWINDOW
                               | 0x08000000                // WS_EX_NOACTIVATE
                               | 0x00000020                // WS_EX_TRANSPARENT
                              );
                return cp;
            }
        }

        private void TrayForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            MinToTray.ShowAllTrayWindows();
        }
    }
}
