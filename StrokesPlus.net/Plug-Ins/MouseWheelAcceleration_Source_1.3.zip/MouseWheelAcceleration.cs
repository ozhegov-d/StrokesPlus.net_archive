﻿
using StrokesPlus.net.Engine;
using StrokesPlus.net.Hooks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static StrokesPlus.net.Hooks.MouseHook;

namespace MouseWheelAcceleration
{
    public static class MouseWheelAcceleration
    {
        public static long ResetMilliseconds 
        {
            get
            {
                return resetTicks / 10000;
            }
            set
            {
                resetTicks = value * 10000;
            }
        }
        public static int WheelCountCap {
            get
            {
                return wheelCountCap;
            }
            set
            {
                wheelCountCap = value;
            }
        }
        public static int WheelCountDivide
        {
            get
            {
                return wheelCountDivide;
            }
            set
            {
                wheelCountDivide = value;
            }
        }

        public static int WheelCountMultiplier
        {
            get
            {
                return wheelCountMultiplier;
            }
            set
            {
                wheelCountMultiplier = value;
            }
        }

        public static bool EnableLogging
        {
            get
            {
                return enableLogging;
            }
            set
            {
                enableLogging = value;
            }
        }

        public static string Log = "";

        private static int wheelCountDivide = 8;
        private static int wheelCountMultiplier = 3;
        private static long resetTicks = 2500000;
        private static long lastTick = 0;
        private static long lastDelta = 0;
        private static int wheelCount = 0;
        private static int wheelCountCap = 40;
        private static bool hooked = false;
        private static bool enableLogging = false;
        private static bool sending = false;
        private static object initLock = new object();
        private static object sendingLock = new object();

        public static void StrokesPlusInitStaticPlugin(dynamic E)
        {
            lock (initLock)
            {
                if (hooked) return;
                hooked = true;
                MouseHook.OnMouseHookButtonEventAsync += MouseButtonEvent;
                Log += DateTime.Now.ToString("hh:mm:ss.fff") + " hooked" + Environment.NewLine;
            }
        }

        public static void MouseButtonEvent(object sender, EventArgs e)
        {
            if (enableLogging)
            {
                Log += DateTime.Now.ToString("hh:mm:ss.fff") + " QueueUserWorkItem" + Environment.NewLine;
            }
            ThreadPool.QueueUserWorkItem(delegate { MouseWheelThread((MouseHookEventArgs)e); });
        }

        public static void MouseWheelThread(MouseHookEventArgs evt)
        {
            if (evt.InjectedByHost || evt.WheelDelta == 0 || sending)
            {
                if (enableLogging)
                {
                    Log += DateTime.Now.ToString("hh:mm:ss.fff") + " Ignoring - evt.InjectedByHost || evt.WheelDelta == 0 || sending" + Environment.NewLine;
                }
                return;
            }

            lock (sendingLock)
            {
                if (evt.WheelDelta != lastDelta || (DateTime.Now.Ticks - lastTick) > resetTicks)
                {
                    wheelCount = 1;
                }
                else if (wheelCount < wheelCountCap)
                {
                    wheelCount++;
                }

                if (enableLogging)
                {
                    Log += DateTime.Now.ToString("hh:mm:ss.fff") + " wheelCount: " + wheelCount + Environment.NewLine;
                }

                if (wheelCount > 1)
                {
                    sending = true;
                    var loopCount = (wheelCount / wheelCountDivide * wheelCountMultiplier) + 1;
                    if (enableLogging)
                    {
                        Log += DateTime.Now.ToString("hh:mm:ss.fff") + " loopCount: " + loopCount + Environment.NewLine;
                    }
                    for (var i = 1; i < loopCount; i++)
                    {
                        if (enableLogging)
                        {
                            Log += DateTime.Now.ToString("hh:mm:ss.fff") + " (loop): " + Environment.NewLine;
                        }
                        ActionFunctions.MouseWheel(evt.Location, evt.HorizontalWheel, evt.WheelDelta);
                    }
                }

                lastDelta = evt.WheelDelta;
                lastTick = DateTime.Now.Ticks;
                if (enableLogging)
                {
                    Log += DateTime.Now.ToString("hh:mm:ss.fff") + " lastDelta: " + lastDelta.ToString() + Environment.NewLine;
                    Log += DateTime.Now.ToString("hh:mm:ss.fff") + " lastTick: " + lastTick.ToString() + Environment.NewLine;
                    Log += DateTime.Now.ToString("hh:mm:ss.fff") + " Existing MouseWheelThread" + Environment.NewLine;
                }
                sending = false;
            }
        }
    }
}
